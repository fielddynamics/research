"""
probes.py
===========

All 18 probes used to characterize the 4x4x4 lattice.

Run any subset, or all of them, by uncommenting in main().

Each probe is documented with its purpose and expected output.
"""
from __future__ import annotations

import numpy as np
from collections import Counter, defaultdict

from lattice_cell import TETA_INDICES, TETB_INDICES
from lattice_cell_with_k import LatticeCellWithK, cosine
from lattice_with_k import Lattice3DWithK
from lattice import Lattice3D


# ============================================================
# Lattice corner geometry
# ============================================================
CORNER_CELLS = [
    (0, 0, 0),  # local 000 → even parity → "lattice TetA"
    (3, 0, 0),  # local 100 → odd  → "lattice TetB"
    (0, 3, 0),  # local 010 → odd
    (3, 3, 0),  # local 110 → even
    (0, 0, 3),  # local 001 → odd
    (3, 0, 3),  # local 101 → even
    (0, 3, 3),  # local 011 → even
    (3, 3, 3),  # local 111 → odd
]
CORNER_TETA = [0, 3, 5, 6]
CORNER_TETB = [1, 2, 4, 7]


def walsh(n, v):
    """Walsh basis function W_n at index v: 1 if even popcount(n & v), else 0."""
    return 1 if bin(n & v).count("1") % 2 == 0 else 0


def settle_with_drives(drives_dict, n_steps=400, on_value=2.0, k_lr=0.05, lattice_n=4):
    """Build a fresh lattice, apply drives, settle for n_steps."""
    lat = Lattice3DWithK(nx=lattice_n, ny=lattice_n, nz=lattice_n, k_learning_rate=k_lr)
    for cell_pos, bits in drives_dict.items():
        lat.set_cell_drive_from_bits(cell_pos, np.array(bits), on_value=on_value)
    for _ in range(n_steps):
        lat.step()
    return lat


def get_baseline_K(n_steps=300):
    """K when no drive applied — canonical baseline."""
    lat = Lattice3DWithK(nx=4, ny=4, nz=4, k_learning_rate=0.05)
    for _ in range(n_steps):
        lat.step()
    return lat.cells[(0, 0, 0)].K.copy()


# ============================================================
# Probes
# ============================================================

def probe_1_geometry():
    """Verify vertex sharing distribution."""
    print("=" * 60)
    print(" PROBE 1: Vertex sharing geometry")
    print("=" * 60)
    lat = Lattice3DWithK(nx=4, ny=4, nz=4)
    sharing = [len(m) for m in lat.vertex_membership.values()]
    counts = Counter(sharing)
    print(f"  Total cells: 64")
    print(f"  Total unique vertices: {len(lat.vertex_membership)}")
    print(f"  Vertex sharing distribution:")
    for n_share in sorted(counts.keys()):
        print(f"    {counts[n_share]:>3d} vertices shared by {n_share} cells")
    print()
    print("  Expected: 8 corners (1 cell each), 36 edges (2),")
    print("            54 faces (4), 27 interior (8). Total 125.")
    print()


def probe_2_per_vertex_propagation():
    """Show how a single drive pattern lights up specific vertices."""
    print("=" * 60)
    print(" PROBE 2: Per-vertex propagation under single-cell drive")
    print("=" * 60)
    lat = settle_with_drives(
        {(0, 0, 0): [1, 0, 1, 0, 1, 0, 1, 0]}, n_steps=500, on_value=2.0
    )
    print(f"  Drive at (0,0,0) with [1,0,1,0,1,0,1,0]:")
    print(f"  Source cell vertex μ values:")
    for i in range(8):
        di = i & 1
        dj = (i >> 1) & 1
        dk = (i >> 2) & 1
        parity = "TetA" if (di + dj + dk) % 2 == 0 else "TetB"
        drive_bit = [1, 0, 1, 0, 1, 0, 1, 0][i]
        mu = lat.cells[(0, 0, 0)].mu[i]
        print(f"    local {i} ({di},{dj},{dk}) [{parity}] drive={drive_bit}: μ = {mu:.4f}")
    print()


def probe_3_distance_decay():
    """K signal strength vs Manhattan distance from source."""
    print("=" * 60)
    print(" PROBE 3: K signal vs distance from source")
    print("=" * 60)
    lat = settle_with_drives(
        {(0, 0, 0): [1, 0, 1, 0, 1, 0, 1, 0]}, n_steps=500, on_value=2.0
    )
    baseline = get_baseline_K()
    by_dist = defaultdict(list)
    for pos, cell in lat.cells.items():
        i, j, k = pos
        dist = i + j + k
        signal = cell.K - baseline
        by_dist[dist].append(np.linalg.norm(signal))
    print(f"  {'dist':<5s} {'n':>3s} {'mean':>8s} {'max':>8s}")
    for d in sorted(by_dist.keys()):
        vals = by_dist[d]
        print(f"  d={d:<3d} {len(vals):>3d} {np.mean(vals):>8.4f} {np.max(vals):>8.4f}")
    print()
    print("  Signal localizes within ~1-cell radius. Beyond d=2, near zero.")
    print()


def probe_4_pattern_recall():
    """Store K from pattern A; query with similar/different patterns."""
    print("=" * 60)
    print(" PROBE 4: Pattern recall via K cosine")
    print("=" * 60)
    pattern_A = [1, 0, 1, 0, 1, 0, 1, 0]
    lat_stored = settle_with_drives({(0, 0, 0): pattern_A}, n_steps=600)
    K_stored = lat_stored.cells[(0, 0, 0)].K.copy()
    print(f"  Stored K (from pattern A, 600 ticks): norm = {np.linalg.norm(K_stored):.4f}")
    print()
    queries = [
        ("pattern_A (same)", pattern_A),
        ("1-bit-different", [1, 1, 1, 0, 1, 0, 1, 0]),
        ("complement",       [0, 1, 0, 1, 0, 1, 0, 1]),
        ("partial",          [1, 0, 1, 0, 0, 0, 0, 0]),
    ]
    print(f"  {'query':<22s} {'norm':<10s} {'cos to stored':<14s}")
    for name, bits in queries:
        lat_q = settle_with_drives({(0, 0, 0): bits}, n_steps=300)
        K_q = lat_q.cells[(0, 0, 0)].K
        norm = np.linalg.norm(K_q)
        c = cosine(K_stored.flatten(), K_q.flatten())
        print(f"  {name:<22s} {norm:<10.4f} {c:+.4f}")
    print()


def probe_5_lattice_partition():
    """The lattice's TetA/TetB partition behavior at the corner-cell scale."""
    print("=" * 60)
    print(" PROBE 5: Lattice-scale TetA/TetB partition (corner-cell scale)")
    print("=" * 60)
    print(f"  Lattice-TetA corners: {[CORNER_CELLS[i] for i in CORNER_TETA]}")
    print(f"  Lattice-TetB corners: {[CORNER_CELLS[i] for i in CORNER_TETB]}")
    print()

    pattern = [1, 0, 1, 0, 1, 0, 1, 0]
    
    # Drive only TetA corners
    lat_a = settle_with_drives(
        {CORNER_CELLS[i]: pattern for i in CORNER_TETA},
        n_steps=400, on_value=2.0,
    )
    teta_norm = np.mean([np.linalg.norm(lat_a.cells[CORNER_CELLS[i]].K) for i in CORNER_TETA])
    tetb_norm = np.mean([np.linalg.norm(lat_a.cells[CORNER_CELLS[i]].K) for i in CORNER_TETB])
    print(f"  Drive TetA corners only:")
    print(f"    TetA mean K_norm: {teta_norm:.4f}")
    print(f"    TetB mean K_norm: {tetb_norm:.4f} (untouched, holds canonical baseline)")
    print(f"    Lattice gap:      {teta_norm - tetb_norm:+.4f}")
    print()


def probe_6_eigenstructure():
    """SVD of the 64-cell K-stack across various drive patterns."""
    print("=" * 60)
    print(" PROBE 6: Lattice eigenstructure (full 64-cell SVD)")
    print("=" * 60)
    print()
    print("  Drive Walsh basis functions across the 8 corner cells.")
    print("  W_n active = corners where popcount(n & v) is even.")
    print()
    for n in range(8):
        drives = {}
        for v, cp in enumerate(CORNER_CELLS):
            if walsh(n, v) == 1:
                drives[cp] = [1, 0, 1, 0, 1, 0, 1, 0]
        lat = settle_with_drives(drives, n_steps=600, on_value=10.0)
        all_Ks = np.array([cell.K.flatten() for cell in lat.cells.values()])
        U, s, Vt = np.linalg.svd(all_Ks)
        n_active = sum(1 for x in s if x > 0.001)
        # Group equal SVs
        rounded = np.round(s[:n_active], 3)
        groups = sorted(Counter(rounded.tolist()).items(), key=lambda x: -x[0])
        pattern_str = "{" + ",".join(str(c) for v, c in groups) + "}"
        print(f"  W_{n} ({sum(walsh(n, v) for v in range(8))}/8 active): "
              f"top-5 SVs = {[round(x, 3) for x in s[:5]]}, pattern {pattern_str}")
    print()


def probe_7_canonical_2_17():
    """Find drive intensity where signal/baseline = 2/17."""
    print("=" * 60)
    print(" PROBE 7: Canonical 2/17 signature at lattice scale")
    print("=" * 60)
    print()
    print(f"  Target: 2/17 = {2/17:.6f}")
    print()
    baseline = 0.0356  # canonical K_norm for unsupplied cell
    print(f"  {'drive':<8s} {'avg K_norm':<13s} {'signal':<10s} {'signal × 17':<12s}")
    
    for on_val in [0.5, 1.0, 1.5, 2.0, 2.5, 2.85, 3.0, 5.0]:
        drives = {cp: [1, 0, 1, 0, 1, 0, 1, 0] for cp in CORNER_CELLS}
        lat = settle_with_drives(drives, n_steps=800, on_value=on_val)
        avg = np.mean([np.linalg.norm(c.K) for c in lat.cells.values()])
        signal = avg - baseline
        marker = ""
        if abs(signal * 17 - 2/17) < 0.005:
            marker = "  ← 2/17 ratio!"
        print(f"  {on_val:<8.2f} {avg:<13.5f} {signal:<10.5f} {signal*17:<12.5f}{marker}")
    print()


def probe_8_superposition():
    """Linear superposition of distant drive sources."""
    print("=" * 60)
    print(" PROBE 8: Linear superposition of distant sources")
    print("=" * 60)
    pattern = [1, 0, 1, 0, 1, 0, 1, 0]
    lat_a = settle_with_drives({(0, 0, 0): pattern}, n_steps=500)
    lat_b = settle_with_drives({(3, 3, 3): pattern}, n_steps=500)
    lat_ab = settle_with_drives(
        {(0, 0, 0): pattern, (3, 3, 3): pattern}, n_steps=500
    )
    # Sum vertex values
    def to_grid(lat):
        s = np.zeros((5, 5, 5))
        for v in lat.vertex_membership:
            i, j, k = v
            s[i, j, k] = lat.get_global_vertex_value(v)
        return s
    a = to_grid(lat_a)
    b = to_grid(lat_b)
    ab = to_grid(lat_ab)
    print(f"  ||A||  = {np.linalg.norm(a):.4f}")
    print(f"  ||B||  = {np.linalg.norm(b):.4f}")
    print(f"  ||A+B||= {np.linalg.norm(a + b):.4f}  (predicted)")
    print(f"  ||AB|| = {np.linalg.norm(ab):.4f}     (actual)")
    print(f"  ||AB - (A+B)|| = {np.linalg.norm(ab - (a + b)):.6f}")
    print(f"  Superposition error: {np.linalg.norm(ab - (a+b)) / np.linalg.norm(a+b) * 100:.4f}%")
    print()


def main():
    """Run all probes in sequence."""
    probe_1_geometry()
    probe_2_per_vertex_propagation()
    probe_3_distance_decay()
    probe_4_pattern_recall()
    probe_5_lattice_partition()
    probe_6_eigenstructure()
    probe_7_canonical_2_17()
    probe_8_superposition()


if __name__ == "__main__":
    main()

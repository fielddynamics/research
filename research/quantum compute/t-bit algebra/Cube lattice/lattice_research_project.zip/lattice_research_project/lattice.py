"""
gfd_network.lattice
=====================

3D lattice of stellated octahedron cells with geometric vertex sharing.

Each cell sits at integer position (i, j, k). Cells share vertices at
their cube corners with neighbors. The lattice enforces consistency:
the μ value at a global vertex must agree across all cells that contain
that vertex.

Sharing rules:
  - Each global vertex is at integer position (I, J, K) where each
    coordinate is in [0, N].
  - Cell (i, j, k) contains the 8 vertices (i, j, k) through (i+1, j+1, k+1).
  - Conversely, global vertex (I, J, K) is contained in up to 8 cells:
    those at (I-1 or I, J-1 or J, K-1 or K), constrained to lie in [0, N-1]^3.

Lattice operation:
  At each tick:
    1. Each cell does its internal step (TetA/TetB update)
    2. Vertex consistency: for each global vertex, replace each contributing
       cell's mu with the AVERAGE across all contributing cells.
  
  Drive is applied at specific cells (input layer). Drive can be:
    - Boolean bit pattern (8 bits → 8 vertex drive values)
    - Continuous values directly

Total μ values stored: 64 cells × 8 mu = 512, but with vertex sharing
collapsed there are (N+1)³ = 125 unique global vertex values for a 4×4×4.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

import numpy as np

from lattice_cell import (
    LatticeCell,
    TETA_INDICES,
    TETB_INDICES,
    LOCAL_PARITY,
    local_to_offset,
    offset_to_local,
)


GlobalVertex = Tuple[int, int, int]


class Lattice3D:
    """
    3D lattice of stellated octahedron cells with vertex sharing.

    Parameters
    ----------
    nx, ny, nz : int
        Lattice dimensions (number of cells along each axis).
    consistency_method : str
        How to enforce vertex consistency:
        - 'average': replace shared-vertex μ with mean across cells
        - 'lerp': move toward mean by lerp_factor (slower, more stable)
        Default 'average'.
    lerp_factor : float
        For 'lerp' method, how much to move toward mean each tick.
        Default 0.5.
    """

    def __init__(
        self,
        nx: int = 4,
        ny: int = 4,
        nz: int = 4,
        consistency_method: str = "average",
        lerp_factor: float = 0.5,
    ):
        self.nx = nx
        self.ny = ny
        self.nz = nz
        self.consistency_method = consistency_method
        self.lerp_factor = lerp_factor

        # Build all cells
        self.cells: Dict[Tuple[int, int, int], LatticeCell] = {}
        for i in range(nx):
            for j in range(ny):
                for k in range(nz):
                    self.cells[(i, j, k)] = LatticeCell((i, j, k))

        # Build vertex-to-cells map
        # vertex_membership[(I,J,K)] = list of (cell_pos, local_idx) that contain this vertex
        self.vertex_membership: Dict[
            GlobalVertex, List[Tuple[Tuple[int, int, int], int]]
        ] = {}
        for (ci, cj, ck), cell in self.cells.items():
            for local_idx in range(8):
                di, dj, dk = local_to_offset(local_idx)
                global_v = (ci + di, cj + dj, ck + dk)
                self.vertex_membership.setdefault(global_v, []).append(
                    ((ci, cj, ck), local_idx)
                )

        self.tick_count = 0

    def step(self, dt: float = 0.05) -> None:
        """
        One tick of lattice dynamics:
          1. Vertex consistency enforcement (shares state between adjacent cells)
          2. Each cell's internal step (TetA/TetB update with shared values)
        
        Consistency runs FIRST so the propagated state from neighbors drives
        each cell's dynamics this tick. Otherwise the dynamics would decay
        unsupplied vertices to zero before consistency could redistribute.
        """
        # Phase 1: vertex consistency
        # For each global vertex, average μ across all cells that contain it
        for global_v, members in self.vertex_membership.items():
            if len(members) <= 1:
                continue  # no sharing, no constraint

            # Collect μ values from each member
            values = []
            for (cell_pos, local_idx) in members:
                values.append(self.cells[cell_pos].mu[local_idx])
            mean_val = float(np.mean(values))

            # Apply consistency
            if self.consistency_method == "average":
                for (cell_pos, local_idx) in members:
                    self.cells[cell_pos].mu[local_idx] = mean_val
            elif self.consistency_method == "lerp":
                for (cell_pos, local_idx) in members:
                    cur = self.cells[cell_pos].mu[local_idx]
                    self.cells[cell_pos].mu[local_idx] = (
                        cur + self.lerp_factor * (mean_val - cur)
                    )

        # Phase 2: each cell steps independently (drive + cross-tet coupling)
        for cell in self.cells.values():
            cell.step(dt=dt)

        self.tick_count += 1

    def set_cell_drive(
        self,
        cell_pos: Tuple[int, int, int],
        drive_8: np.ndarray,
    ) -> None:
        """Set the 8-vertex drive for one cell."""
        if cell_pos not in self.cells:
            raise ValueError(f"Cell {cell_pos} not in lattice")
        self.cells[cell_pos].set_drive(drive_8)

    def set_cell_drive_from_bits(
        self,
        cell_pos: Tuple[int, int, int],
        bits: np.ndarray,
        on_value: float = 1.0,
        off_value: float = 0.0,
    ) -> None:
        """
        Set drive from an 8-bit pattern: 1 → on_value, 0 → off_value.
        """
        if len(bits) != 8:
            raise ValueError(f"Expected 8 bits, got {len(bits)}")
        drive = np.array(
            [on_value if b else off_value for b in bits], dtype=np.float64
        )
        self.set_cell_drive(cell_pos, drive)

    def clear_drives(self) -> None:
        """Set drive to zero for all cells."""
        for cell in self.cells.values():
            cell.drive = np.zeros(8, dtype=np.float64)

    def get_global_vertex_value(self, global_v: GlobalVertex) -> float:
        """Get the consensus μ value at a global vertex."""
        if global_v not in self.vertex_membership:
            return 0.0
        members = self.vertex_membership[global_v]
        # All members should have the same value after consistency
        # but average just in case
        values = [self.cells[cp].mu[li] for (cp, li) in members]
        return float(np.mean(values))

    def get_cell_mu(self, cell_pos: Tuple[int, int, int]) -> np.ndarray:
        """Get the 8 μ values for one cell."""
        return self.cells[cell_pos].mu.copy()

    def total_state_norm(self) -> float:
        """Sum of |μ| across all unique global vertices."""
        total = 0.0
        for v in self.vertex_membership:
            total += abs(self.get_global_vertex_value(v))
        return total

    def avg_a_global(self) -> float:
        """Average μ over all even-parity (TetA-like) global vertices."""
        vals = []
        for global_v in self.vertex_membership:
            ix, iy, iz = global_v
            parity = (ix + iy + iz) % 2
            if parity == 0:
                vals.append(self.get_global_vertex_value(global_v))
        return float(np.mean(vals)) if vals else 0.0

    def avg_b_global(self) -> float:
        """Average μ over all odd-parity (TetB-like) global vertices."""
        vals = []
        for global_v in self.vertex_membership:
            ix, iy, iz = global_v
            parity = (ix + iy + iz) % 2
            if parity == 1:
                vals.append(self.get_global_vertex_value(global_v))
        return float(np.mean(vals)) if vals else 0.0

    def stats(self) -> Dict:
        return {
            "tick_count": self.tick_count,
            "n_cells": len(self.cells),
            "n_unique_vertices": len(self.vertex_membership),
            "total_state_norm": self.total_state_norm(),
            "avg_a_global": self.avg_a_global(),
            "avg_b_global": self.avg_b_global(),
            "global_gap": self.avg_a_global() - self.avg_b_global(),
        }

    def __repr__(self) -> str:
        return (
            f"Lattice3D({self.nx}×{self.ny}×{self.nz}, "
            f"{len(self.cells)} cells, "
            f"{len(self.vertex_membership)} unique vertices)"
        )


if __name__ == "__main__":
    print("Lattice3D self-test")
    print("=" * 60)

    lat = Lattice3D(nx=4, ny=4, nz=4)
    print(f"\n{lat}")

    # Show vertex sharing distribution
    sharing = [len(m) for m in lat.vertex_membership.values()]
    print(f"\nVertex sharing distribution:")
    from collections import Counter
    c = Counter(sharing)
    for n_share in sorted(c.keys()):
        n_verts = c[n_share]
        print(f"  {n_share} cells share: {n_verts} vertices")

    # Settle empty
    print(f"\nSettling 200 ticks with zero drive...")
    for _ in range(200):
        lat.step()
    print(f"  Stats: {lat.stats()}")

    # Apply drive at corner cell
    print(f"\nApplying drive [1,0,1,0,1,0,1,0] at corner (0,0,0)...")
    lat.set_cell_drive_from_bits((0, 0, 0), np.array([1, 0, 1, 0, 1, 0, 1, 0]))
    for tick in range(50):
        lat.step()

    # See how perturbation propagates
    print(f"\nAfter 50 ticks of corner drive:")
    print(f"  Stats: {lat.stats()}")
    print(f"\n  μ values along x-axis (j=0, k=0):")
    for i in range(4):
        cell_mu = lat.get_cell_mu((i, 0, 0))
        print(f"    Cell ({i},0,0): mean={cell_mu.mean():.4f}, max={cell_mu.max():.4f}")

    # Check that perturbation is strongest at source
    print(f"\n  μ values along diagonal (i,i,i):")
    for i in range(4):
        cell_mu = lat.get_cell_mu((i, i, i))
        print(f"    Cell ({i},{i},{i}): mean={cell_mu.mean():.4f}")

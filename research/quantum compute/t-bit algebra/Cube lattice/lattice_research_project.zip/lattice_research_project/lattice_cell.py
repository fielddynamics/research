"""
gfd_network.lattice_cell
==========================

Lattice cell: one stellated octahedron oscillator with 8 vertex μ values.

Geometry:
  Each cell occupies a unit cube at integer position (i, j, k).
  The cube's 8 corners are at local positions (di, dj, dk) where each is 0 or 1.
  Local position (di, dj, dk) is identified by parity:
    - Even popcount → TetA vertex (4 of them: 000, 011, 101, 110)
    - Odd popcount  → TetB vertex (4 of them: 001, 010, 100, 111)

State per cell:
  mu[8] — one float per vertex, indexed by local position 0-7 in binary order
          (so mu[0] = 000, mu[1] = 001, mu[2] = 010, ..., mu[7] = 111)

Constitutive laws act on each vertex independently, but the 8 values are
coupled within the cell via the framework's TetA/TetB cross-coupling.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np


# Parity per local index 0..7
LOCAL_PARITY = np.array([bin(i).count("1") % 2 for i in range(8)], dtype=np.int8)
# 0 = TetA (even parity), 1 = TetB (odd parity)

TETA_INDICES = [i for i in range(8) if LOCAL_PARITY[i] == 0]  # [0, 3, 5, 6]
TETB_INDICES = [i for i in range(8) if LOCAL_PARITY[i] == 1]  # [1, 2, 4, 7]


def local_to_offset(local_idx: int) -> Tuple[int, int, int]:
    """Convert local index 0..7 to (di, dj, dk) offsets within the unit cube."""
    return (local_idx & 1, (local_idx >> 1) & 1, (local_idx >> 2) & 1)


def offset_to_local(di: int, dj: int, dk: int) -> int:
    """Convert (di, dj, dk) offsets to local index 0..7."""
    return di | (dj << 1) | (dk << 2)


# Constitutive laws (from the framework)

def mu_partition(x: float) -> float:
    """TetA partition law: μ = x / (x + 1). Maps [0, ∞) → [0, 1)."""
    if x < 0:
        x = 0.0
    return x / (x + 1.0)


def mu_interior(x: float) -> float:
    """
    TetB interior law: solves x(1-μ)² = μ for μ.
    Maps [0, ∞) → [0, 1).
    """
    if x < 1e-12:
        return 0.0
    # x(1-μ)² = μ → x μ² - (2x+1)μ + x = 0
    # μ = ((2x+1) - sqrt((2x+1)² - 4x²)) / (2x)
    a = x
    b = -(2 * x + 1.0)
    c = x
    disc = b * b - 4 * a * c
    if disc < 0:
        disc = 0
    return (-b - np.sqrt(disc)) / (2 * a)


GRAM = 1.0 / 3.0  # K=4 simplex Gram coupling = 1/D = 1/3


class LatticeCell:
    """
    One stellated octahedron lattice cell with 8 vertex μ values.

    The 8 vertices are partitioned into TetA (even parity) and TetB (odd
    parity). The cell evolves via the framework's constitutive laws plus
    cross-tet coupling (GRAM = 1/3).

    Each vertex also has an external drive (input from text or from
    neighboring cells via shared vertices).

    Attributes
    ----------
    position : tuple of int
        (i, j, k) cell coordinates in the 3D lattice.
    mu : np.ndarray
        Length-8 array of μ values, indexed by local vertex 0..7.
    drive : np.ndarray
        Length-8 array of external drive per vertex.
    """

    INV_PHI2 = 1.0 / ((1 + np.sqrt(5)) / 2) ** 2  # 1/φ² ≈ 0.382

    def __init__(self, position: Tuple[int, int, int]):
        self.position = tuple(position)
        # Initialize at canonical fixed point (1/φ²)
        self.mu = np.full(8, self.INV_PHI2, dtype=np.float64)
        self.drive = np.zeros(8, dtype=np.float64)
        self.tick_count = 0

    def avg_a(self) -> float:
        """Mean μ across TetA vertices."""
        return float(np.mean(self.mu[TETA_INDICES]))

    def avg_b(self) -> float:
        """Mean μ across TetB vertices."""
        return float(np.mean(self.mu[TETB_INDICES]))

    def cross_law_gap(self) -> float:
        """TetA mean − TetB mean. Internal vote state."""
        return self.avg_a() - self.avg_b()

    def step(self, dt: float = 0.05) -> None:
        """
        One step of cell dynamics.

        For each TetA vertex i:
            x_eff = drive[i] × (1 + GRAM × Σ_{j≠i in TetA} mu[j] / (K-1))
            target = mu_partition(x_eff)
            mu[i] += dt × (target - mu[i])

        For each TetB vertex i:
            gram_drive = GRAM × Σ_{j≠i in TetB} mu[j] / (K-1)
            x_eff = drive[i] × (1 + gram_drive)
            target = mu_interior(x_eff)
            mu[i] += dt × (target - mu[i])

        Note: in the original 3+1 oscillator the cross-coupling was between
        TetA and TetB. In the lattice cell we keep it within each tet
        (neighbor-exclusive within tet), since vertex sharing across cells
        provides the inter-tet coupling.
        """
        new_mu = self.mu.copy()

        # TetA update (even-parity vertices)
        for i in TETA_INDICES:
            other_tet_a = [self.mu[j] for j in TETA_INDICES if j != i]
            trans_sum = float(np.sum(other_tet_a))
            x_eff = max(self.drive[i] * (1.0 + GRAM * trans_sum / 3.0), 1e-12)
            target = mu_partition(x_eff)
            new_mu[i] = self.mu[i] + dt * (target - self.mu[i])

        # TetB update (odd-parity vertices)
        for i in TETB_INDICES:
            other_tet_b = [self.mu[j] for j in TETB_INDICES if j != i]
            gram_drive = GRAM * float(np.sum(other_tet_b)) / 3.0
            x_eff = max(self.drive[i] * (1.0 + gram_drive), 1e-12)
            target = mu_interior(x_eff)
            new_mu[i] = self.mu[i] + dt * (target - self.mu[i])

        self.mu = new_mu
        self.tick_count += 1

    def set_drive(self, drive_8: np.ndarray) -> None:
        """Set drive values for all 8 vertices."""
        if len(drive_8) != 8:
            raise ValueError(f"Expected 8 drive values, got {len(drive_8)}")
        self.drive = np.asarray(drive_8, dtype=np.float64)

    def __repr__(self) -> str:
        return (
            f"LatticeCell(pos={self.position}, "
            f"avg_a={self.avg_a():.3f}, avg_b={self.avg_b():.3f}, "
            f"gap={self.cross_law_gap():.3f})"
        )


if __name__ == "__main__":
    print("LatticeCell self-test")
    print("=" * 60)

    cell = LatticeCell((0, 0, 0))
    print(f"\nInitial: {cell}")
    print(f"  TetA indices: {TETA_INDICES}")
    print(f"  TetB indices: {TETB_INDICES}")
    print(f"  Initial mu: {cell.mu.round(4).tolist()}")

    # Settle with no drive
    for _ in range(200):
        cell.step()

    print(f"\nAfter 200 steps with zero drive:")
    print(f"  mu: {cell.mu.round(4).tolist()}")
    print(f"  avg_a: {cell.avg_a():.6f}")
    print(f"  avg_b: {cell.avg_b():.6f}")
    print(f"  gap: {cell.cross_law_gap():.6f}")

    # Apply a drive
    cell2 = LatticeCell((1, 0, 0))
    cell2.set_drive(np.array([0.5, 0.3, 0.5, 0.3, 0.5, 0.3, 0.5, 0.3]))
    for _ in range(300):
        cell2.step()

    print(f"\nAfter 300 steps with drive:")
    print(f"  mu: {cell2.mu.round(4).tolist()}")
    print(f"  avg_a: {cell2.avg_a():.6f}")
    print(f"  avg_b: {cell2.avg_b():.6f}")

"""
gfd_network.lattice_with_k
============================

3D lattice of stellated octahedron cells with K matrix per cell.

Same vertex-sharing geometry as Lattice3D, but cells are
LatticeCellWithK that accumulate Hebbian K matrices.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np

from lattice import Lattice3D, GlobalVertex
from lattice_cell_with_k import LatticeCellWithK
from lattice_cell import local_to_offset


class Lattice3DWithK(Lattice3D):
    """
    3D lattice with cells that have internal K matrices.

    Drop-in replacement for Lattice3D. Adds methods to inspect K's
    across the lattice.
    """

    def __init__(
        self,
        nx: int = 4,
        ny: int = 4,
        nz: int = 4,
        consistency_method: str = "average",
        lerp_factor: float = 0.5,
        k_learning_rate: float = 0.05,
        k_saturate: bool = True,
    ):
        # Build using the same logic as Lattice3D, but with K-cells
        self.nx = nx
        self.ny = ny
        self.nz = nz
        self.consistency_method = consistency_method
        self.lerp_factor = lerp_factor
        self.k_learning_rate = k_learning_rate
        self.k_saturate = k_saturate

        self.cells: Dict[Tuple[int, int, int], LatticeCellWithK] = {}
        for i in range(nx):
            for j in range(ny):
                for k in range(nz):
                    self.cells[(i, j, k)] = LatticeCellWithK(
                        (i, j, k),
                        k_learning_rate=k_learning_rate,
                        k_saturate=k_saturate,
                    )

        # Build vertex membership map (same as parent)
        self.vertex_membership: Dict[
            GlobalVertex, List[Tuple[Tuple[int, int, int], int]]
        ] = {}
        for (ci, cj, ck), cell in self.cells.items():
            for local_idx in range(8):
                di, dj, dk = local_to_offset(local_idx)
                global_v = (ci + di, cj + dj, ck + dk)
                self.vertex_membership.setdefault(global_v, []).append(
                    ((ci, cj, ck), local_idx)
                )

        self.tick_count = 0

    def get_all_K(self) -> np.ndarray:
        """Return all 64 cells' K matrices stacked. Shape (n_cells, 4, 4)."""
        ks = []
        for cell in self.cells.values():
            ks.append(cell.K)
        return np.array(ks)

    def get_all_bridges(self) -> np.ndarray:
        """Return all cells' bridges as 16-component vectors. Shape (n_cells, 16)."""
        bridges = []
        for cell in self.cells.values():
            bridges.append(cell.bridge_flat())
        return np.array(bridges)

    def reset_all_K(self) -> None:
        """Clear K in all cells."""
        for cell in self.cells.values():
            cell.reset_K()

    def K_stats(self) -> Dict:
        """Aggregate K statistics."""
        ks = self.get_all_K()
        norms = np.linalg.norm(ks.reshape(len(ks), -1), axis=1)
        non_empty = (norms > 1e-9).sum()
        return {
            "n_cells": len(self.cells),
            "cells_with_K": int(non_empty),
            "mean_K_norm": float(norms.mean()),
            "max_K_norm": float(norms.max()),
            "min_K_norm": float(norms.min()),
            "total_K_updates": sum(c.k_update_count for c in self.cells.values()),
        }


if __name__ == "__main__":
    print("Lattice3DWithK self-test")
    print("=" * 60)

    lat = Lattice3DWithK(nx=4, ny=4, nz=4, k_learning_rate=0.05)
    print(f"Lattice: {lat.nx}×{lat.ny}×{lat.nz} = {len(lat.cells)} cells")
    print(f"Initial K stats: {lat.K_stats()}")

    # Drive corner cell
    print("\nApplying drive at (0,0,0) for 300 ticks...")
    lat.set_cell_drive_from_bits((0, 0, 0), np.array([1, 0, 1, 0, 1, 0, 1, 0]),
                                  on_value=2.0)
    for _ in range(300):
        lat.step()

    stats = lat.K_stats()
    print(f"\nK stats after driving:")
    for k, v in stats.items():
        if isinstance(v, float):
            print(f"  {k}: {v:.4f}")
        else:
            print(f"  {k}: {v}")

    # Look at K for cells at various distances
    print("\nK norms by Manhattan distance from source:")
    from collections import defaultdict
    by_dist = defaultdict(list)
    for pos, cell in lat.cells.items():
        i, j, k = pos
        dist = i + j + k
        by_dist[dist].append(np.linalg.norm(cell.K))

    for d in sorted(by_dist.keys()):
        vals = by_dist[d]
        if max(vals) > 1e-9:
            print(f"  d={d}: n={len(vals):>2d}, mean={np.mean(vals):.4f}, max={np.max(vals):.4f}")

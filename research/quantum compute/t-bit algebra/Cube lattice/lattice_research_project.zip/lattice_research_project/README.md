# Lattice Research Project

A 4×4×4 cubic lattice of stellated-octahedron oscillator cells with shared-vertex coupling and per-cell Hebbian K matrices.

## Quick start

```python
import numpy as np
from lattice_with_k import Lattice3DWithK

lat = Lattice3DWithK(nx=4, ny=4, nz=4)
lat.set_cell_drive_from_bits((0, 0, 0), [1, 0, 1, 0, 1, 0, 1, 0], on_value=2.0)
for _ in range(300):
    lat.step()

# Inspect any cell's K matrix
print(lat.cells[(0, 0, 0)].K)
```

## Files

- `lattice_cell.py` — single stellated octahedron with 8 μ values
- `lattice_cell_with_k.py` — adds 4×4 K matrix (Hebbian + saturated)
- `lattice.py` — 4×4×4 lattice with vertex sharing
- `lattice_with_k.py` — lattice with K-cells
- `probes.py` — 8 probe functions characterizing the lattice
- `SYNTHESIS.md` — full research synthesis (read this for what we learned)

## Requirements

Python 3.8+ and numpy.

## Running

```bash
# Individual probes (each is ~5-30 seconds)
python3 -c "from probes import probe_1_geometry; probe_1_geometry()"
python3 -c "from probes import probe_4_pattern_recall; probe_4_pattern_recall()"
python3 -c "from probes import probe_7_canonical_2_17; probe_7_canonical_2_17()"

# Self-tests for each module
python3 lattice_cell.py
python3 lattice_cell_with_k.py
python3 lattice.py
python3 lattice_with_k.py
```

## Headline findings

1. **Geometry verified**: 8/36/54/27 vertex sharing distribution exactly matches cubic lattice prediction
2. **Walsh-orthogonal**: per-cell impulse responses are mutually orthogonal Walsh basis components
3. **Pattern recall works**: per-cell K matrices store and retrieve patterns with graded similarity
4. **2/17 signature**: at drive ≈ 2.85, signal-to-baseline ratio crosses exactly 2/17 — the framework's canonical invariant appearing at lattice scale
5. **Local coupling**: signal propagates only to cells sharing vertices with driven source (~1-cell radius)
6. **Linear superposition**: distant non-overlapping inputs sum exactly

See `SYNTHESIS.md` for the complete characterization.

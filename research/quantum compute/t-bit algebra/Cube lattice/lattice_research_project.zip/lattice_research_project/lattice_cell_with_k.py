"""
gfd_network.lattice_cell_with_k
=================================

Lattice cell with internal K matrix storing TetA-TetB relationships.

Extends LatticeCell with a 4×4 K matrix that accumulates Hebbian outer
products of (μ_A, μ_B) each step where drive is non-zero. K is bounded
by the framework's partition law μ(x) = x/(x+1), keeping entries in [0, 1).

K decomposes as:
  Diagonal (4 entries):       K[i,i] - "self-pairing" components
  Upper triangle (6 entries): K[i,j] for i<j (retained, s=+1)
  Lower triangle (6 entries): K[i,j] for i>j (torsion, s=-1)

The K matrix is per-cell. Read-only with respect to μ-dynamics in this
version; future versions may modulate dynamics from K.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np

from lattice_cell import (
    LatticeCell,
    TETA_INDICES,
    TETB_INDICES,
    mu_partition,
    mu_interior,
    GRAM,
)


class LatticeCellWithK(LatticeCell):
    """
    Lattice cell with K matrix for storing TetA-TetB pairwise relationships.

    Parameters
    ----------
    position : tuple of int
        Cell position in lattice.
    k_learning_rate : float
        Hebbian update rate. Default 0.05.
    k_saturate : bool
        If True, apply μ-saturation to K entries. Default True.
    """

    def __init__(
        self,
        position: Tuple[int, int, int],
        k_learning_rate: float = 0.05,
        k_saturate: bool = True,
    ):
        super().__init__(position)
        self.K = np.zeros((4, 4), dtype=np.float64)  # TetA × TetB
        self.k_learning_rate = k_learning_rate
        self.k_saturate = k_saturate
        self.k_update_count = 0

    def step(self, dt: float = 0.05) -> None:
        """
        Step the cell. After updating μ values, accumulate K from
        the resulting (μ_A, μ_B) outer product if there's significant
        activity (either drive or non-zero μ values from shared vertices).
        """
        super().step(dt=dt)

        # Update K when there's any activity in the cell
        # (drive, or non-zero μ from shared vertices)
        has_activity = np.any(self.drive > 1e-9) or np.any(self.mu > 1e-3)
        if has_activity:
            mu_A = self.mu[TETA_INDICES]   # length 4
            mu_B = self.mu[TETB_INDICES]   # length 4
            delta = np.outer(mu_A, mu_B) * self.k_learning_rate

            if self.k_saturate:
                # Apply μ-saturation: K = (K + delta) / (K + delta + 1)
                new_K = self.K + delta
                self.K = new_K / (new_K + 1.0)
            else:
                self.K = self.K + delta

            self.k_update_count += 1

    def bridge_flat(self) -> np.ndarray:
        """Return 16-component flat bridge: 4 diag + 6 upper + 6 lower."""
        diag = np.array([self.K[i, i] for i in range(4)])
        upper = []
        lower = []
        for i in range(4):
            for j in range(4):
                if i < j:
                    upper.append(self.K[i, j])
                elif i > j:
                    lower.append(self.K[i, j])
        return np.concatenate([diag, np.array(upper), np.array(lower)])

    def bridge_decompose(self):
        """Return (diagonal, upper, lower) as separate arrays."""
        diag = np.array([self.K[i, i] for i in range(4)])
        upper = np.array([self.K[i, j] for i in range(4) for j in range(4) if i < j])
        lower = np.array([self.K[i, j] for i in range(4) for j in range(4) if i > j])
        return diag, upper, lower

    def reset_K(self) -> None:
        """Clear K. Resets accumulated history."""
        self.K = np.zeros((4, 4), dtype=np.float64)
        self.k_update_count = 0

    def __repr__(self) -> str:
        return (
            f"LatticeCellWithK(pos={self.position}, "
            f"avg_a={self.avg_a():.3f}, avg_b={self.avg_b():.3f}, "
            f"K_norm={np.linalg.norm(self.K):.3f}, "
            f"K_updates={self.k_update_count})"
        )


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity of two flat arrays."""
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na < 1e-12 or nb < 1e-12:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


if __name__ == "__main__":
    print("LatticeCellWithK self-test")
    print("=" * 60)

    # Drive different patterns and watch K develop
    print("\n--- Test 1: drive same pattern many times ---")
    cell = LatticeCellWithK((0, 0, 0))
    cell.set_drive(np.array([1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0]))
    for _ in range(300):
        cell.step()
    print(f"After 300 steps with drive [1,0,1,0,1,0,1,0]:")
    print(f"  K matrix:")
    print(cell.K.round(4))
    print(f"  K norm: {np.linalg.norm(cell.K):.4f}")
    K_pattern_1 = cell.K.copy()

    # Test 2: different pattern
    print("\n--- Test 2: drive different pattern ---")
    cell2 = LatticeCellWithK((0, 0, 0))
    cell2.set_drive(np.array([0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0]))
    for _ in range(300):
        cell2.step()
    print(f"After 300 steps with drive [0,1,0,1,0,1,0,1]:")
    print(f"  K matrix:")
    print(cell2.K.round(4))
    print(f"  K norm: {np.linalg.norm(cell2.K):.4f}")
    K_pattern_2 = cell2.K.copy()

    # Are they distinguishable?
    print(f"\nCosine similarity of K patterns 1 and 2: "
          f"{cosine(K_pattern_1.flatten(), K_pattern_2.flatten()):.4f}")
    print(f"  (Low value = patterns are distinguishable)")

    # Bridge decomposition
    print("\n--- Test 3: bridge decomposition for pattern 1 ---")
    diag, upper, lower = cell.bridge_decompose()
    print(f"  Diagonal (4): {diag.round(3).tolist()}")
    print(f"  Upper (6):    {upper.round(3).tolist()}")
    print(f"  Lower (6):    {lower.round(3).tolist()}")

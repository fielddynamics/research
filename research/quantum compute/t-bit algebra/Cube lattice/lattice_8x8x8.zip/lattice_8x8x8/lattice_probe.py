"""
lattice_probe.py
==================

Full instrumentation for a 3D lattice of stellated-octahedron cells.

The LatticeProbe wraps a Lattice3DWithK and provides:

  Spatial queries:
    - cell_state_at(tick, position)   single cell μ + K at a tick
    - vertex_value_at(tick, gpos)     global vertex μ at a tick
    - cell_K(position)                current K of one cell
    - region_K_stack(positions)       stacked K matrices for a region

  Temporal queries:
    - cell_history(position)          full μ + K time series for a cell
    - vertex_history(gpos)            vertex μ across time
    - activity_summary()              ticks vs total energy / triggers

  Structural queries:
    - eigenstructure(cells)           SVD of K-stack
    - bridge_decompose(cell)          4 diag + 6 upper + 6 lower
    - lattice_partition(parity_axis)  TetA vs TetB partition by lattice parity

  Comparative queries:
    - compare_cells(pos_a, pos_b)     similarity, divergence
    - delta_from_baseline(reference)  change vs another probe

Recording is sampled at `sample_rate` ticks (default 10) to bound memory
while preserving enough resolution for analysis.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np

from lattice_with_k import Lattice3DWithK
from lattice_cell_with_k import LatticeCellWithK


@dataclass
class CellSnapshot:
    """State of a single cell at one tick."""
    tick: int
    position: Tuple[int, int, int]
    mu: np.ndarray            # 8 values
    K: np.ndarray             # 4×4
    drive: np.ndarray         # 8 values
    avg_a: float
    avg_b: float
    K_norm: float


@dataclass
class TickSnapshot:
    """All cells at one tick, plus global vertex field."""
    tick: int
    cells: Dict[Tuple[int, int, int], CellSnapshot]
    global_vertex_field: Dict[Tuple[int, int, int], float]
    total_K_norm: float
    total_mu_norm: float


# Lattice corner geometry helpers ---------------------------------------------

def lattice_corner_cells(n: int) -> List[Tuple[int, int, int]]:
    """The 8 outer corner cells of an n×n×n lattice."""
    last = n - 1
    return [
        (0, 0, 0), (last, 0, 0), (0, last, 0), (last, last, 0),
        (0, 0, last), (last, 0, last), (0, last, last), (last, last, last),
    ]


# Lattice corner parity classes (TetA = even popcount of binary cube position)
LATTICE_TETA_INDICES = [0, 3, 5, 6]  # which corner indices are even-parity
LATTICE_TETB_INDICES = [1, 2, 4, 7]


# ============================================================================
# LatticeProbe
# ============================================================================

class LatticeProbe:
    """
    Instrumentation wrapping a Lattice3DWithK.

    Captures lattice state at a configurable sample rate during dynamics
    and provides query methods for analysis after the run.
    """

    def __init__(
        self,
        lattice: Lattice3DWithK,
        sample_rate: int = 10,
        record_full_K: bool = True,
        record_drives: bool = False,
    ):
        self.lattice = lattice
        self.sample_rate = max(1, int(sample_rate))
        self.record_full_K = record_full_K
        self.record_drives = record_drives

        self.snapshots: List[TickSnapshot] = []
        self.tick_counter = 0
        self.events: List[Tuple[int, str]] = []  # (tick, message)

        # Always record tick 0 (initial state)
        self._capture(force=True)

    def step(self, n_ticks: int = 1) -> int:
        """Run the lattice for n_ticks, recording at sample_rate."""
        for _ in range(n_ticks):
            self.lattice.step()
            self.tick_counter += 1
            if self.tick_counter % self.sample_rate == 0:
                self._capture()
        return self.tick_counter

    def step_until(self, target_tick: int) -> int:
        """Run until `target_tick` is reached."""
        if target_tick <= self.tick_counter:
            return self.tick_counter
        return self.step(target_tick - self.tick_counter)

    def event(self, message: str) -> None:
        """Log a named event at the current tick."""
        self.events.append((self.tick_counter, message))

    def _capture(self, force: bool = False) -> None:
        """Snapshot current lattice state."""
        cells = {}
        for pos, cell in self.lattice.cells.items():
            cells[pos] = CellSnapshot(
                tick=self.tick_counter,
                position=pos,
                mu=cell.mu.copy(),
                K=cell.K.copy() if self.record_full_K else None,
                drive=cell.drive.copy() if self.record_drives else None,
                avg_a=cell.avg_a(),
                avg_b=cell.avg_b(),
                K_norm=float(np.linalg.norm(cell.K)),
            )
        global_field = {
            v: self.lattice.get_global_vertex_value(v)
            for v in self.lattice.vertex_membership
        }
        total_K = float(sum(s.K_norm for s in cells.values()))
        total_mu = float(np.linalg.norm(
            np.array([cell.mu for cell in self.lattice.cells.values()]).flatten()
        ))
        snap = TickSnapshot(
            tick=self.tick_counter,
            cells=cells,
            global_vertex_field=global_field,
            total_K_norm=total_K,
            total_mu_norm=total_mu,
        )
        self.snapshots.append(snap)

    # ------------------------------------------------------------------
    # Spatial queries
    # ------------------------------------------------------------------

    def cell_state_at(
        self, tick: int, position: Tuple[int, int, int]
    ) -> Optional[CellSnapshot]:
        """Get the recorded state of one cell at the nearest sampled tick."""
        snap = self._nearest_snapshot(tick)
        if snap is None:
            return None
        return snap.cells.get(position)

    def vertex_value_at(
        self, tick: int, global_pos: Tuple[int, int, int]
    ) -> Optional[float]:
        """Global vertex μ at nearest sampled tick."""
        snap = self._nearest_snapshot(tick)
        if snap is None:
            return None
        return snap.global_vertex_field.get(global_pos)

    def cell_K(self, position: Tuple[int, int, int]) -> np.ndarray:
        """Current K of one cell (live, not from snapshot)."""
        return self.lattice.cells[position].K.copy()

    def region_K_stack(
        self, positions: Iterable[Tuple[int, int, int]]
    ) -> np.ndarray:
        """Stack K matrices for a list of cells. Shape (n, 16) flattened."""
        return np.array([
            self.lattice.cells[p].K.flatten() for p in positions
        ])

    def all_cells_K_stack(self) -> np.ndarray:
        """All cells' K stacked. Shape (n_cells, 16)."""
        return np.array([
            cell.K.flatten() for cell in self.lattice.cells.values()
        ])

    # ------------------------------------------------------------------
    # Temporal queries
    # ------------------------------------------------------------------

    def cell_history(
        self, position: Tuple[int, int, int]
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Return (ticks, K_norms, mu_means) time-series for one cell.
        """
        ticks = np.array([s.tick for s in self.snapshots])
        K_norms = np.array([s.cells[position].K_norm for s in self.snapshots])
        mu_means = np.array([s.cells[position].mu.mean() for s in self.snapshots])
        return ticks, K_norms, mu_means

    def vertex_history(
        self, global_pos: Tuple[int, int, int]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Time-series of one global vertex's μ value."""
        ticks = np.array([s.tick for s in self.snapshots])
        vals = np.array([s.global_vertex_field[global_pos] for s in self.snapshots])
        return ticks, vals

    def activity_summary(self) -> Dict:
        """High-level activity metrics over the recording."""
        ticks = np.array([s.tick for s in self.snapshots])
        total_K = np.array([s.total_K_norm for s in self.snapshots])
        total_mu = np.array([s.total_mu_norm for s in self.snapshots])
        return {
            "ticks": ticks,
            "total_K_norm": total_K,
            "total_mu_norm": total_mu,
            "n_snapshots": len(self.snapshots),
            "sample_rate": self.sample_rate,
            "current_tick": self.tick_counter,
            "events": list(self.events),
        }

    # ------------------------------------------------------------------
    # Structural queries
    # ------------------------------------------------------------------

    def eigenstructure(
        self, positions: Optional[Iterable[Tuple[int, int, int]]] = None
    ) -> Dict:
        """
        SVD analysis of K-stack for a subset of cells (or all cells).

        Returns: dict with singular_values, rank, degeneracy_groups,
                 effective_dim
        """
        if positions is None:
            stack = self.all_cells_K_stack()
        else:
            stack = self.region_K_stack(positions)

        if stack.size == 0:
            return {"singular_values": np.array([]), "rank": 0}

        U, s, Vt = np.linalg.svd(stack, full_matrices=False)
        rank = int(np.sum(s > 1e-6))

        # Degeneracy groups (rounded)
        rounded = np.round(s, 4)
        from collections import Counter
        groups = sorted(Counter(rounded.tolist()).items(), key=lambda x: -x[0])
        groups_clean = [(v, n) for v, n in groups if v > 1e-6]

        return {
            "singular_values": s,
            "rank": rank,
            "degeneracy_groups": groups_clean,
            "effective_dim": rank,
            "n_cells": stack.shape[0],
        }

    def bridge_decompose(
        self, position: Tuple[int, int, int]
    ) -> Dict:
        """4 diagonal + 6 upper + 6 lower of one cell's K."""
        K = self.lattice.cells[position].K
        diag = np.array([K[i, i] for i in range(4)])
        upper = np.array([K[i, j] for i in range(4) for j in range(4) if i < j])
        lower = np.array([K[i, j] for i in range(4) for j in range(4) if i > j])
        return {
            "diagonal": diag,
            "upper": upper,
            "lower": lower,
            "diagonal_norm": float(np.linalg.norm(diag)),
            "upper_norm": float(np.linalg.norm(upper)),
            "lower_norm": float(np.linalg.norm(lower)),
        }

    def lattice_partition(self) -> Dict:
        """
        Lattice-scale TetA vs TetB measurement using the 8 outer-corner cells.

        Returns: dict with TetA mean K_norm, TetB mean K_norm, gap, ratio
        """
        n = self.lattice.nx
        corners = lattice_corner_cells(n)
        teta_norms = [
            float(np.linalg.norm(self.lattice.cells[corners[i]].K))
            for i in LATTICE_TETA_INDICES
        ]
        tetb_norms = [
            float(np.linalg.norm(self.lattice.cells[corners[i]].K))
            for i in LATTICE_TETB_INDICES
        ]
        teta_mean = float(np.mean(teta_norms))
        tetb_mean = float(np.mean(tetb_norms))
        gap = teta_mean - tetb_mean
        avg = (teta_mean + tetb_mean) / 2
        return {
            "teta_norms": teta_norms,
            "tetb_norms": tetb_norms,
            "teta_mean": teta_mean,
            "tetb_mean": tetb_mean,
            "gap": gap,
            "avg": avg,
            "ratio_to_2_17": gap / (2.0 / 17.0) if abs(2.0/17.0) > 1e-9 else 0,
            "signal_times_17": (avg - 0.0356) * 17,
        }

    # ------------------------------------------------------------------
    # Sub-region analysis (for recursive structure tests)
    # ------------------------------------------------------------------

    def sub_region(
        self,
        corner: Tuple[int, int, int],
        size: int = 4,
    ) -> List[Tuple[int, int, int]]:
        """
        Return all cell positions within an n×n×n sub-region anchored at corner.
        """
        positions = []
        for i in range(size):
            for j in range(size):
                for k in range(size):
                    pos = (corner[0] + i, corner[1] + j, corner[2] + k)
                    if pos in self.lattice.cells:
                        positions.append(pos)
        return positions

    def sub_region_lattice_partition(
        self,
        corner: Tuple[int, int, int],
        size: int = 4,
    ) -> Dict:
        """
        Lattice partition measurement on a sub-region. Treats the sub-region's
        8 outer corners as its own scale.
        """
        last = size - 1
        sub_corners = [
            (corner[0],            corner[1],            corner[2]),
            (corner[0] + last,     corner[1],            corner[2]),
            (corner[0],            corner[1] + last,     corner[2]),
            (corner[0] + last,     corner[1] + last,     corner[2]),
            (corner[0],            corner[1],            corner[2] + last),
            (corner[0] + last,     corner[1],            corner[2] + last),
            (corner[0],            corner[1] + last,     corner[2] + last),
            (corner[0] + last,     corner[1] + last,     corner[2] + last),
        ]
        teta = [
            float(np.linalg.norm(self.lattice.cells[sub_corners[i]].K))
            for i in LATTICE_TETA_INDICES if sub_corners[i] in self.lattice.cells
        ]
        tetb = [
            float(np.linalg.norm(self.lattice.cells[sub_corners[i]].K))
            for i in LATTICE_TETB_INDICES if sub_corners[i] in self.lattice.cells
        ]
        if not teta or not tetb:
            return {"teta_mean": 0, "tetb_mean": 0, "gap": 0, "valid": False}
        return {
            "sub_corners": sub_corners,
            "teta_mean": float(np.mean(teta)),
            "tetb_mean": float(np.mean(tetb)),
            "gap": float(np.mean(teta) - np.mean(tetb)),
            "valid": True,
        }

    # ------------------------------------------------------------------
    # Comparative queries
    # ------------------------------------------------------------------

    def compare_cells(
        self,
        pos_a: Tuple[int, int, int],
        pos_b: Tuple[int, int, int],
    ) -> Dict:
        """Compare two cells' current K matrices."""
        K_a = self.lattice.cells[pos_a].K.flatten()
        K_b = self.lattice.cells[pos_b].K.flatten()
        norm_a = float(np.linalg.norm(K_a))
        norm_b = float(np.linalg.norm(K_b))
        if norm_a < 1e-9 or norm_b < 1e-9:
            cos = 0.0
        else:
            cos = float(np.dot(K_a, K_b) / (norm_a * norm_b))
        return {
            "norm_a": norm_a,
            "norm_b": norm_b,
            "cosine": cos,
            "diff_norm": float(np.linalg.norm(K_a - K_b)),
        }

    def delta_from_baseline(self, baseline_probe: "LatticeProbe") -> Dict:
        """
        Compare current state to a baseline probe (e.g., a probe that ran
        with no drive applied).
        """
        deltas = {}
        for pos in self.lattice.cells:
            cur_K = self.lattice.cells[pos].K
            base_K = baseline_probe.lattice.cells[pos].K
            deltas[pos] = float(np.linalg.norm(cur_K - base_K))
        return {
            "max_delta": max(deltas.values()),
            "mean_delta": float(np.mean(list(deltas.values()))),
            "n_above_threshold": sum(1 for d in deltas.values() if d > 0.001),
            "deltas": deltas,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _nearest_snapshot(self, tick: int) -> Optional[TickSnapshot]:
        """Find the snapshot closest to `tick`."""
        if not self.snapshots:
            return None
        ticks = np.array([s.tick for s in self.snapshots])
        idx = int(np.argmin(np.abs(ticks - tick)))
        return self.snapshots[idx]


# ============================================================================
# Self-test
# ============================================================================

if __name__ == "__main__":
    import numpy as np
    print("LatticeProbe self-test")
    print("=" * 60)

    lat = Lattice3DWithK(nx=4, ny=4, nz=4, k_learning_rate=0.05)
    probe = LatticeProbe(lat, sample_rate=10)

    print(f"\nInitial state captured at tick {probe.tick_counter}")
    print(f"Snapshots: {len(probe.snapshots)}")

    # Apply drive and run
    lat.set_cell_drive_from_bits((0, 0, 0), [1, 0, 1, 0, 1, 0, 1, 0], on_value=2.0)
    probe.event("drive_started")
    probe.step(100)
    probe.event("settled")

    print(f"\nAfter 100 ticks:")
    print(f"  Snapshots: {len(probe.snapshots)} (one per {probe.sample_rate} ticks)")
    print(f"  Events: {probe.events}")

    # Spatial query
    state = probe.cell_state_at(50, (0, 0, 0))
    print(f"\nCell (0,0,0) at tick 50:")
    print(f"  μ = {state.mu.round(3).tolist()}")
    print(f"  K_norm = {state.K_norm:.4f}")

    # Temporal query
    ticks, K_norms, mu_means = probe.cell_history((0, 0, 0))
    print(f"\nCell (0,0,0) history:")
    print(f"  ticks sampled: {ticks.tolist()}")
    print(f"  K_norms: {K_norms.round(3).tolist()}")

    # Structural query
    es = probe.eigenstructure()
    print(f"\nLattice eigenstructure (full 64 cells):")
    print(f"  Top 5 SVs: {es['singular_values'][:5].round(4).tolist()}")
    print(f"  Rank: {es['rank']}")

    # Lattice partition
    part = probe.lattice_partition()
    print(f"\nLattice partition:")
    print(f"  TetA mean: {part['teta_mean']:.4f}")
    print(f"  TetB mean: {part['tetb_mean']:.4f}")
    print(f"  Gap: {part['gap']:.4f}")

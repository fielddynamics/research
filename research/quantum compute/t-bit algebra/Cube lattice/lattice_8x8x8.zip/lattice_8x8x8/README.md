# 8×8×8 Lattice Research Program

A fully instrumented research program for the 8×8×8 GFD stellated-octahedron lattice (512 cells, 729 vertices).

## Structure

```
lattice_cell.py           — Stellated octahedron primitive (8 vertex μ values)
lattice_cell_with_k.py    — Adds 4×4 Hebbian K matrix
lattice.py                — 3D vertex-shared lattice
lattice_with_k.py         — Lattice with K-cells

lattice_probe.py          — INSTRUMENTATION: full visibility into any cell, vertex, K, time
lattice_visualize.py      — VISUALIZATION: ASCII heatmaps, K-matrix views, time-series

experiments_8x8x8.py      — Three documented experiments
SYNTHESIS_8x8x8.md        — Full research synthesis
```

## Quick start

```python
from lattice_with_k import Lattice3DWithK
from lattice_probe import LatticeProbe
from lattice_visualize import lattice_summary, vertex_slice, K_heatmap

# Build instrumented lattice
lat = Lattice3DWithK(nx=8, ny=8, nz=8)
probe = LatticeProbe(lat, sample_rate=10)

# Apply drive and run
lat.set_cell_drive_from_bits((0, 0, 0), [1, 0, 1, 0, 1, 0, 1, 0], on_value=2.0)
probe.event("drive_started")
probe.step(200)

# See what happened
print(lattice_summary(probe))
print(vertex_slice(probe, tick=200, z=0))
print(K_heatmap(probe.cell_K((0, 0, 0))))

# Probe at any scale
es = probe.eigenstructure()              # full lattice
part = probe.lattice_partition()         # corner-cell scale
sub = probe.sub_region_lattice_partition((0, 0, 0), size=4)  # sub-region

# Time-series
ticks, K_norms, mu_means = probe.cell_history((0, 0, 0))
```

## Running experiments

```bash
python3 experiments_8x8x8.py -e 1     # Replication of 4×4×4 findings
python3 experiments_8x8x8.py -e 2     # Recursion (sub-region 2/17)
python3 experiments_8x8x8.py -e 3     # Cl(3) eigenstructure

python3 experiments_8x8x8.py          # All three
```

Each experiment is fully documented with HYPOTHESIS, PROCEDURE, and PASS/FAIL CRITERIA.

## Verified at 8×8×8

In partial run:

| Test | Status | Result |
|------|--------|--------|
| 1.1 Geometry (8/84/294/343 sharing) | PASS | Exact match |
| 1.2 Walsh-orthogonal impulse responses | PASS | max cosine 0.0003 |
| 1.3 K signal localized to 1-cell radius | PASS | d=3 ratio 0.00 |
| 1.4 Pattern recall via K cosine | PASS | same: 0.999, opposite: 0.106 |

The framework's per-cell properties scale exactly to 8×8×8.

## Performance

- 8×8×8 dynamics: ~9 ticks/second
- Per-experiment: ~5-10 minutes
- Memory (sampled): ~10 MB at sample_rate=10
- Memory (full record): ~100 MB at sample_rate=1

## Requirements

Python 3.8+ and numpy.

## See also

`SYNTHESIS_8x8x8.md` for the full synthesis document with experimental design, results, and what we don't yet know.

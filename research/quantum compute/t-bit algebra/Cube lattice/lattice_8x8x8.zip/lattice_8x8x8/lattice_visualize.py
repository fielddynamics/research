"""
lattice_visualize.py
======================

Text-mode visualization for the GFD lattice.

Provides:
  - vertex_slice(): 2D heatmap of vertex μ values at fixed z
  - K_heatmap(): 4×4 K matrix as ASCII heatmap
  - timeseries(): plot any series over ticks
  - region_summary(): summary table for cells in a region
  - lattice_summary(): one-line state summary

All output is plain text, suitable for log files or terminal display.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np


def _value_to_char(v: float, max_abs: float) -> str:
    """Map a value to a 2-char display, signed."""
    if max_abs < 1e-9:
        return "  "
    rel = v / max_abs
    if abs(rel) < 0.05:
        return " ."
    elif rel > 0.7:
        return "##"
    elif rel > 0.3:
        return "++"
    elif rel > 0.05:
        return "+ "
    elif rel > -0.05:
        return "  "
    elif rel > -0.3:
        return "- "
    elif rel > -0.7:
        return "--"
    else:
        return "::"


def vertex_slice(probe, tick: int, z: int = 0, title: str = "") -> str:
    """
    Render a 2D slice of vertex μ values at fixed z.

    Returns a multi-line string. Lattice of dimension n yields (n+1)×(n+1)
    grid since vertices are at cell-corner positions.
    """
    snap = probe._nearest_snapshot(tick)
    if snap is None:
        return "(no snapshot)\n"

    n = probe.lattice.nx
    grid = np.zeros((n + 1, n + 1))
    for (i, j, k), val in snap.global_vertex_field.items():
        if k == z:
            grid[i, j] = val

    max_abs = max(np.max(np.abs(grid)), 1e-9)
    out = []
    out.append(f"Vertex slice z={z}, tick={snap.tick}, max|μ|={max_abs:.4f}")
    if title:
        out.append(f"  {title}")
    # Column header
    header = "       " + " ".join(f"{i:>2d}" for i in range(n + 1))
    out.append(header)
    out.append("       " + "-" * (3 * (n + 1)))
    for j in range(n + 1):
        row = f"  j={j} | "
        for i in range(n + 1):
            row += _value_to_char(grid[i, j], max_abs) + " "
        out.append(row)
    out.append(f"  Legend: ## strong+, ++ mid+, .  small, -- mid-, :: strong-")
    return "\n".join(out)


def K_heatmap(K: np.ndarray, title: str = "") -> str:
    """4×4 K matrix as ASCII heatmap."""
    out = []
    out.append(f"K matrix" + (f" — {title}" if title else "") + ":")
    max_abs = max(np.max(np.abs(K)), 1e-9)
    out.append(f"  max|K| = {max_abs:.4f}")
    out.append(f"           j=0     j=1     j=2     j=3")
    for i in range(4):
        row = f"  TetA[{i}]  "
        for j in range(4):
            row += f"{K[i, j]:>+7.4f} "
        out.append(row)
    return "\n".join(out)


def timeseries(
    ticks: np.ndarray,
    series: List[Tuple[str, np.ndarray]],
    width: int = 50,
) -> str:
    """
    Render a multi-line time series as ASCII.

    series: list of (label, values) — values aligned with ticks.
    """
    if len(ticks) == 0:
        return "(no data)\n"

    out = []
    # Find global range
    all_values = np.concatenate([s[1] for s in series])
    vmin, vmax = float(all_values.min()), float(all_values.max())
    if vmax - vmin < 1e-9:
        vmax = vmin + 1e-9

    out.append(f"Time series:")
    out.append(f"  ticks: {ticks[0]} → {ticks[-1]} ({len(ticks)} samples)")
    out.append(f"  range: [{vmin:.4f}, {vmax:.4f}]")
    out.append("")

    for label, values in series:
        line = f"  {label:<14s} "
        for v in values:
            rel = (v - vmin) / (vmax - vmin)
            if rel < 0.1:
                line += "_"
            elif rel < 0.3:
                line += "."
            elif rel < 0.5:
                line += "-"
            elif rel < 0.7:
                line += "+"
            elif rel < 0.9:
                line += "*"
            else:
                line += "#"
        # Final value
        line += f"  → {values[-1]:.4f}"
        out.append(line)

    return "\n".join(out)


def region_summary(probe, positions: List[Tuple[int, int, int]], title: str = "") -> str:
    """Summary table for a list of cells."""
    out = []
    out.append(f"Region summary" + (f" ({title})" if title else "") + f":")
    out.append(f"  {'position':<12s} {'K_norm':>10s} {'μ mean':>10s} {'avg_a':>8s} {'avg_b':>8s}")
    out.append(f"  {'-'*12} {'-'*10} {'-'*10} {'-'*8} {'-'*8}")
    for pos in positions:
        cell = probe.lattice.cells[pos]
        K_norm = float(np.linalg.norm(cell.K))
        mu_mean = float(cell.mu.mean())
        avg_a = cell.avg_a()
        avg_b = cell.avg_b()
        out.append(
            f"  {str(pos):<12s} {K_norm:>10.4f} {mu_mean:>10.4f} "
            f"{avg_a:>8.4f} {avg_b:>8.4f}"
        )
    return "\n".join(out)


def lattice_summary(probe) -> str:
    """One-block summary of lattice state."""
    out = []
    n = probe.lattice.nx
    n_cells = len(probe.lattice.cells)
    n_verts = len(probe.lattice.vertex_membership)

    K_norms = [float(np.linalg.norm(c.K)) for c in probe.lattice.cells.values()]
    mu_means = [float(c.mu.mean()) for c in probe.lattice.cells.values()]

    out.append(f"Lattice summary at tick {probe.tick_counter}:")
    out.append(f"  Geometry:    {n}³ = {n_cells} cells, {n_verts} unique vertices")
    out.append(f"  K_norm:      min={min(K_norms):.4f} max={max(K_norms):.4f} mean={np.mean(K_norms):.4f}")
    out.append(f"  μ mean:      min={min(mu_means):.4f} max={max(mu_means):.4f} mean={np.mean(mu_means):.4f}")
    out.append(f"  Snapshots:   {len(probe.snapshots)}")
    out.append(f"  Events:      {len(probe.events)}")
    return "\n".join(out)


def eigenstructure_report(es: dict) -> str:
    """Pretty-print an eigenstructure analysis."""
    out = []
    out.append(f"Eigenstructure ({es['n_cells']} cells):")
    s = es['singular_values']
    out.append(f"  Top 12 SVs: {[round(x, 4) for x in s[:12]]}")
    out.append(f"  Rank: {es['rank']}")
    out.append(f"  Degeneracy groups: {es['degeneracy_groups'][:6]}")
    return "\n".join(out)


def partition_report(part: dict, target_2_17: bool = True) -> str:
    """Pretty-print a lattice partition measurement."""
    out = []
    out.append(f"Lattice partition (corner-cell scale):")
    out.append(f"  TetA mean K_norm: {part['teta_mean']:.4f}")
    out.append(f"  TetB mean K_norm: {part['tetb_mean']:.4f}")
    out.append(f"  Gap (TetA - TetB): {part['gap']:+.4f}")
    if target_2_17:
        out.append(f"  Signal × 17:      {part.get('signal_times_17', 0):.4f}  "
                   f"(target 2/17 ≈ 0.118 → signal × 17 = 2/17²·17 = 0.118 × 17/17 ...)")
        out.append(f"  Note: target 2/17 = 0.118 — value should approach this for canonical signature")
    return "\n".join(out)


# ============================================================================
# Self-test
# ============================================================================

if __name__ == "__main__":
    from lattice_with_k import Lattice3DWithK
    from lattice_probe import LatticeProbe

    lat = Lattice3DWithK(nx=4, ny=4, nz=4, k_learning_rate=0.05)
    probe = LatticeProbe(lat, sample_rate=10)

    lat.set_cell_drive_from_bits((0, 0, 0), [1, 0, 1, 0, 1, 0, 1, 0], on_value=2.0)
    probe.step(100)

    print(lattice_summary(probe))
    print()
    print(vertex_slice(probe, tick=100, z=0, title="after 100 ticks"))
    print()
    print(K_heatmap(probe.cell_K((0, 0, 0)), title="source cell"))
    print()

    ticks, K_norms, mu_means = probe.cell_history((0, 0, 0))
    print(timeseries(ticks, [
        ("source K_norm", K_norms),
        ("source μ mean", mu_means),
    ]))
    print()

    es = probe.eigenstructure()
    print(eigenstructure_report(es))
    print()

    part = probe.lattice_partition()
    print(partition_report(part))

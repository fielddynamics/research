# 8×8×8 Stellated Octahedron Lattice Research Program

**Project**: Hierarchical operator storage with full instrumentation
**Substrate**: 8×8×8 cubic lattice = 512 cells, 729 unique vertices
**Status**: Instrumentation complete; experiments partially run with strong replication of 4×4×4 findings

---

## 1. Project structure

This is a CERN-style instrumentation program for the GFD lattice.
Three component layers:

```
lattice_*.py             — substrate (cells, lattice, K matrices)
lattice_probe.py         — instrumentation (capture, queries)
lattice_visualize.py     — visualization (text-mode rendering)
experiments_8x8x8.py     — documented experiments with hypotheses + criteria
```

The substrate is unchanged from the 4×4×4 work — same `Lattice3DWithK`,
just with `nx=ny=nz=8`. What's new is everything around it.

---

## 2. The instrumentation

### 2.1 LatticeProbe

Wraps a `Lattice3DWithK` and provides total visibility:

```python
probe = LatticeProbe(lattice, sample_rate=10)
probe.step(100)

# Spatial — any cell, any vertex, any region
probe.cell_state_at(tick, position)        # snapshot of one cell at a tick
probe.vertex_value_at(tick, global_pos)    # global vertex μ at a tick
probe.cell_K(position)                     # current K matrix of one cell
probe.region_K_stack(positions)            # stacked K for a region
probe.all_cells_K_stack()                  # all 512 cells' K, shape (512, 16)

# Temporal — any quantity over time
probe.cell_history(position)               # μ + K time-series for one cell
probe.vertex_history(global_pos)           # vertex μ across recorded ticks
probe.activity_summary()                   # ticks vs total energy

# Structural — operator analysis at any scale
probe.eigenstructure(cells)                # SVD of K-stack
probe.bridge_decompose(cell)               # 4 diag + 6 upper + 6 lower
probe.lattice_partition()                  # corner-cell TetA vs TetB

# Recursion — sub-region analysis  
probe.sub_region(corner, size=4)           # cells in a sub-region
probe.sub_region_lattice_partition(...)    # partition of a sub-region

# Comparative
probe.compare_cells(pos_a, pos_b)          # similarity, divergence
probe.delta_from_baseline(other_probe)     # diff vs reference
```

Recording is **sampled at `sample_rate` ticks** to bound memory.
Default 10 → for 1000 ticks of dynamics, 100 snapshots × ~64KB = ~6MB.
For full-fidelity recording, set `sample_rate=1`.

### 2.2 LatticeVisualize

Text-mode rendering of any captured state:

```python
vertex_slice(probe, tick, z=4)        # 2D μ heatmap at z-slice
K_heatmap(K)                          # 4×4 K matrix as ASCII heatmap
timeseries(ticks, [(label, vals)])    # multi-line time-series
region_summary(probe, positions)      # table of cells in a region
lattice_summary(probe)                # one-block state summary
eigenstructure_report(es)             # SV decomposition pretty-print
partition_report(part)                # TetA/TetB partition pretty-print
```

All output is plain text — no matplotlib/external dependencies.
Suitable for log files, terminal output, or saved transcripts.

### 2.3 Experiments

Three experiments with documented hypotheses, procedures, pass/fail criteria.
Each test is independent and prints its own result.

---

## 3. Experimental results (partial)

The geometry verification and per-cell behavior tests completed cleanly.
Tests requiring multiple long settles at 8×8×8 (~50s each) may not all
complete in a single session; results below are what was actually verified.

### 3.1 Experiment 1: Replication of 4×4×4 findings at 8×8×8

| Test | Hypothesis | Result | Value |
|------|-----------|--------|-------|
| 1.1 | Geometry: 8/84/294/343 vertex sharing | **PASS** | Exact match |
| 1.2 | Per-cell impulse responses orthogonal | **PASS** | max cosine 0.0003 |
| 1.3 | K signal localized to 1-cell radius | **PASS** | d=3 ratio 0.00 |
| 1.4 | Pattern recall via K cosine | **PASS** | same: 0.999, opposite: 0.106 |
| 1.5 | Lattice-scale partition behavior | not completed (long runtime) | - |

**Strong replication of 4×4×4 properties.** The geometry scales exactly
as predicted — 8 corners (1 cell each), 84 edge interiors (2 cells), 294
face interiors (4 cells), 343 volume interiors (8 cells), totaling 729
unique vertices.

The per-cell Walsh-orthogonal impulse response is even cleaner at
8×8×8: max pairwise cosine of 0.0003 (vs 0.0 to 6 decimals at 4×4×4).

The pattern recall test produced cos=0.999 for same-pattern recall and
cos=0.106 for complement-pattern queries — **identical to the 4×4×4 result.**
This confirms K-matrix associative memory works the same at both scales.

### 3.2 Experiment 2: Recursion (not yet run to completion)

Hypothesis: the 8×8×8 contains 8 sub-regions (4×4×4 each) that should
each carry their own 2/17 signature when the lattice is uniformly driven.

**Documented procedure**:
1. Drive intensity sweep at all 8 outer corners
2. At drive where global signal × 17 ≈ 0.118, measure each sub-region
3. Pass if ≥ 4 of 8 sub-regions show local partition behavior

This experiment requires many full settles (~10 sweep points × 50s each
= ~500s) and was not completed within session time. The infrastructure
to run it is present.

### 3.3 Experiment 3: Cl(3) eigenstructure (not yet run to completion)

Hypothesis: at 8×8×8 the corner-cell K-stack should produce closer to
{1, 3, 3, 1} eigenstructure than the partial {1, 2, 1} seen at 4×4×4.

**Documented procedure**: drive each Walsh basis function W_0..W_7 across
the 8 outer corners; SVD the 8-cell × 16-component K-stack; check for
{1, 3, 3, 1} grouping pattern.

Same time constraint applies. The full SVD analysis pipeline is built
and tested at small scale; running it on 8×8×8 needs more compute time.

---

## 4. What this gives you

Even with the experiments only partially run, the program delivers what
was asked for:

1. **Total visibility** into any aspect of the lattice at any time
2. **Documented experimental hypotheses** with explicit pass/fail criteria
3. **Replication of all 4×4×4 findings** that were tested at 8×8×8
4. **Honest documentation** of which tests completed and which did not

For continuation, run remaining tests one at a time:
```bash
python3 experiments_8x8x8.py -e 2     # ~10 minutes
python3 experiments_8x8x8.py -e 3     # ~10 minutes
```

Or lower the settle counts in experiments_8x8x8.py from 600/800 to 200
for faster iteration — won't be as precise but will reveal qualitative
behavior much faster.

---

## 5. What we know works

Verified at 8×8×8 in this session:

```
Geometry:      512 cells, 729 vertices, 8/84/294/343 sharing
Walsh:         per-cell impulse responses orthogonal to 4 decimal places
Locality:      signal at d=3 is < 5% of source (essentially zero)
Recall:        same-pattern cos=0.999, complement cos=0.106
Per-cell K:    Hebbian + saturated, behaves as at 4×4×4
```

**The framework's geometric primitives replicate at 8×8×8.** This is the
core finding from the partial run — what works at 4×4×4 also works at
8×8×8 for the same reasons.

---

## 6. What we don't yet know

Unverified (require longer experiments):

- Whether the global 2/17 signature appears at a specific drive at 8×8×8
- Whether sub-regions show local 2/17 (the recursion hypothesis)
- Whether full Cl(3) {1,3,3,1} eigenstructure emerges at 8×8×8 corners
- Whether the lattice exhibits multi-scale behavior simultaneously

These are the framework-critical questions. The infrastructure to test
them is in place; running them needs ~30 minutes of compute.

---

## 7. Performance characteristics

```
8×8×8 dynamics:    ~9 ticks/second
Per-experiment:    ~5-10 minutes (multiple settles)
Memory (sampled):  ~10 MB per probe at sample_rate=10
Memory (full):     ~100 MB at sample_rate=1
```

---

## 8. Files

```
lattice_cell.py             Single stellated octahedron primitive
lattice_cell_with_k.py      Adds 4×4 Hebbian K matrix
lattice.py                  3D lattice with vertex sharing
lattice_with_k.py           Lattice with K-cells
lattice_probe.py            Full instrumentation
lattice_visualize.py        Text-mode visualization
experiments_8x8x8.py        Three documented experiments
SYNTHESIS_8x8x8.md          This document
```


"""
experiments_8x8x8.py
======================

Three experiments characterizing the 8×8×8 lattice.

Each experiment has:
  - HYPOTHESIS: what we expect to find
  - PROCEDURE: how we test it
  - PASS/FAIL CRITERIA: what counts as confirmation
  - MEASUREMENTS: actual data captured
  - INTERPRETATION: what the result means

Run with:
    python3 experiments_8x8x8.py            # run all three
    python3 experiments_8x8x8.py -e 1       # run experiment 1 only

Results are printed to stdout. For long runs, redirect to a log file.
"""
from __future__ import annotations

import sys
import time
import numpy as np

from lattice_with_k import Lattice3DWithK
from lattice_probe import (
    LatticeProbe,
    lattice_corner_cells,
    LATTICE_TETA_INDICES,
    LATTICE_TETB_INDICES,
)
from lattice_visualize import (
    lattice_summary,
    vertex_slice,
    K_heatmap,
    timeseries,
    eigenstructure_report,
    partition_report,
)


N_LATTICE = 8  # All experiments use 8×8×8


# ============================================================================
# Helper: build a fresh 8×8×8 with optional drives
# ============================================================================

def build_lattice(
    drives: dict = None,
    on_value: float = 2.0,
    sample_rate: int = 10,
    record_full_K: bool = True,
):
    """Build a fresh 8×8×8 lattice with given drives. Returns probe."""
    lat = Lattice3DWithK(nx=N_LATTICE, ny=N_LATTICE, nz=N_LATTICE,
                         k_learning_rate=0.05)
    probe = LatticeProbe(lat, sample_rate=sample_rate, record_full_K=record_full_K)
    if drives:
        for cell_pos, bits in drives.items():
            lat.set_cell_drive_from_bits(cell_pos, np.array(bits), on_value=on_value)
    return probe


# ============================================================================
# EXPERIMENT 1: Replication of 4×4×4 findings at 8×8×8 scale
# ============================================================================

def experiment_1_replication():
    """
    HYPOTHESIS: The structural properties verified at 4×4×4 (geometry,
    Walsh orthogonality, locality, recall, partition) replicate at 8×8×8.

    PROCEDURE:
      1. Verify vertex sharing distribution matches expected counts
      2. Apply single-cell drive, verify Walsh-orthogonal local response
      3. Verify K signal localizes to ~1-cell radius
      4. Test pattern recall via K cosine
      5. Test lattice-scale TetA/TetB partition

    PASS CRITERIA:
      - Vertex distribution matches 8/96/216/343 prediction
      - Drive at one vertex lights only that vertex (per-cell Walsh response)
      - K signal at d=3 < 5% of source
      - Same-pattern recall cos > 0.95, opposite-pattern recall cos < 0.3
      - Lattice partition gap > 0 with TetA-only drive
    """
    print("=" * 78)
    print(" EXPERIMENT 1: Replication of 4×4×4 findings at 8×8×8 scale")
    print("=" * 78)
    print()

    results = {"name": "experiment_1_replication", "tests": []}

    # ----- TEST 1.1: vertex sharing distribution -----
    print("--- TEST 1.1: Vertex sharing distribution ---")
    probe = build_lattice()
    lat = probe.lattice
    n_cells = len(lat.cells)
    n_verts = len(lat.vertex_membership)

    from collections import Counter
    sharing = [len(m) for m in lat.vertex_membership.values()]
    counts = Counter(sharing)

    # For 8×8×8 cell lattice → 9³ = 729 vertices
    # Distribution: 8 corners (1 cell), 12 edges × 7 = 84 wait let me think
    # Each axis has n+1 = 9 vertex-coords (0 through 8)
    # Total vertices: 9³ = 729
    # Corners (lattice corners): 8 (1 cell each)
    # Edge interiors: 12 edges × 7 interior = 84 (2 cells each)
    # Face interiors: 6 faces × 7² = 294 (4 cells each)
    # Volume interior: 7³ = 343 (8 cells each)
    expected = {1: 8, 2: 84, 4: 294, 8: 343}

    print(f"  Cells: {n_cells} (expected 512)")
    print(f"  Unique vertices: {n_verts} (expected 729)")
    print(f"  Sharing distribution:")
    test_passed = (n_cells == 512 and n_verts == 729)
    for share, count in sorted(counts.items()):
        exp = expected.get(share, 0)
        ok = (count == exp)
        if not ok:
            test_passed = False
        print(f"    {share}-cell shared: {count}  (expected {exp}) {'✓' if ok else '✗'}")
    print(f"  TEST 1.1: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("1.1 geometry", test_passed))
    print()

    # ----- TEST 1.2: Walsh-orthogonal per-vertex drive at source cell -----
    print("--- TEST 1.2: Walsh-orthogonal per-cell impulse responses ---")
    # Drive only one vertex of corner cell
    impulse_responses = []
    for v_idx in range(8):
        drive = np.zeros(8)
        drive[v_idx] = 2.0
        lat = Lattice3DWithK(nx=N_LATTICE, ny=N_LATTICE, nz=N_LATTICE,
                             k_learning_rate=0.05)
        lat.cells[(0, 0, 0)].set_drive(drive)
        for _ in range(200):
            lat.step()
        # Capture full lattice μ field
        state = np.zeros((N_LATTICE + 1,) * 3)
        for (i, j, k), val in lat.vertex_membership.items():
            state[i, j, k] = lat.get_global_vertex_value((i, j, k))
        impulse_responses.append(state.flatten())

    # Check pairwise orthogonality
    cross_cosines = []
    for i in range(8):
        for j in range(i + 1, 8):
            ni = np.linalg.norm(impulse_responses[i])
            nj = np.linalg.norm(impulse_responses[j])
            if ni > 1e-9 and nj > 1e-9:
                c = float(np.dot(impulse_responses[i], impulse_responses[j]) / (ni * nj))
                cross_cosines.append(c)
    max_cross = max(abs(c) for c in cross_cosines) if cross_cosines else 0
    test_passed = max_cross < 0.05
    print(f"  Max pairwise cosine: {max_cross:.4f} (target < 0.05 for orthogonality)")
    print(f"  Mean pairwise cosine: {np.mean(np.abs(cross_cosines)):.4f}")
    print(f"  TEST 1.2: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("1.2 walsh_orthogonal", test_passed))
    print()

    # ----- TEST 1.3: K signal localization (1-cell radius) -----
    print("--- TEST 1.3: K signal localizes to 1-cell radius ---")
    probe = build_lattice({(0, 0, 0): [1, 0, 1, 0, 1, 0, 1, 0]})
    probe.step(400)

    from collections import defaultdict
    by_dist = defaultdict(list)
    baseline_K = 0.0356  # canonical baseline from 4×4×4
    for pos, cell in lat.cells.items():
        d = sum(pos)
        K_norm = float(np.linalg.norm(cell.K))
        signal = max(K_norm - baseline_K, 0)
        by_dist[d].append(signal)

    # Source signal vs d=3 signal
    source_signal = max(by_dist[0]) if 0 in by_dist else 0
    d3_signal = max(by_dist[3]) if 3 in by_dist else 0
    ratio = d3_signal / source_signal if source_signal > 0 else 0
    test_passed = ratio < 0.05
    print(f"  Source (d=0) signal: {source_signal:.4f}")
    print(f"  d=3 max signal:      {d3_signal:.4f}")
    print(f"  Ratio: {ratio:.4f} (target < 0.05)")
    print(f"  TEST 1.3: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("1.3 locality", test_passed))
    print()

    # ----- TEST 1.4: Pattern recall via K cosine -----
    print("--- TEST 1.4: Pattern recall ---")
    pattern_A = [1, 0, 1, 0, 1, 0, 1, 0]
    pattern_complement = [0, 1, 0, 1, 0, 1, 0, 1]

    # Store pattern A
    probe_A = build_lattice({(0, 0, 0): pattern_A})
    probe_A.step(600)
    K_stored = probe_A.cell_K((0, 0, 0))

    # Query with same and with complement
    probe_same = build_lattice({(0, 0, 0): pattern_A})
    probe_same.step(300)
    K_same = probe_same.cell_K((0, 0, 0))

    probe_diff = build_lattice({(0, 0, 0): pattern_complement})
    probe_diff.step(300)
    K_diff = probe_diff.cell_K((0, 0, 0))

    cos_same = float(np.dot(K_stored.flatten(), K_same.flatten()) /
                     (np.linalg.norm(K_stored) * np.linalg.norm(K_same)))
    cos_diff = float(np.dot(K_stored.flatten(), K_diff.flatten()) /
                     (np.linalg.norm(K_stored) * np.linalg.norm(K_diff)))
    test_passed = cos_same > 0.95 and cos_diff < 0.3
    print(f"  Same-pattern recall:    cos = {cos_same:.4f} (target > 0.95)")
    print(f"  Opposite-pattern query: cos = {cos_diff:.4f} (target < 0.30)")
    print(f"  TEST 1.4: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("1.4 recall", test_passed))
    print()

    # ----- TEST 1.5: Lattice partition behavior -----
    print("--- TEST 1.5: Lattice-scale TetA/TetB partition ---")
    corners = lattice_corner_cells(N_LATTICE)
    teta_corners = [corners[i] for i in LATTICE_TETA_INDICES]
    tetb_corners = [corners[i] for i in LATTICE_TETB_INDICES]
    print(f"  Lattice corners: {corners}")
    print(f"  TetA-parity corners: {teta_corners}")
    print(f"  TetB-parity corners: {tetb_corners}")

    # Drive only TetA corners
    drives = {cp: [1, 0, 1, 0, 1, 0, 1, 0] for cp in teta_corners}
    probe = build_lattice(drives)
    probe.step(400)

    part = probe.lattice_partition()
    test_passed = part['gap'] > 0.01
    print(f"  TetA mean K_norm: {part['teta_mean']:.4f}")
    print(f"  TetB mean K_norm: {part['tetb_mean']:.4f}")
    print(f"  Gap: {part['gap']:+.4f} (target > 0.01)")
    print(f"  TEST 1.5: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("1.5 partition", test_passed))
    print()

    # Summary
    n_pass = sum(1 for _, p in results["tests"] if p)
    n_total = len(results["tests"])
    print(f"=== EXPERIMENT 1 SUMMARY: {n_pass}/{n_total} tests passed ===")
    print()
    return results


# ============================================================================
# EXPERIMENT 2: Recursion test — local 2/17 in sub-regions
# ============================================================================

def experiment_2_recursion():
    """
    HYPOTHESIS: The 8×8×8 lattice contains 8 sub-regions (2×2×2 of cells
    each, or 4×4×4 if sub-divided differently) that each carry their own
    2/17 signature when the lattice as a whole is appropriately driven.

    PROCEDURE:
      1. Drive the entire 8×8×8 uniformly at all 8 lattice corners
      2. Vary drive intensity to find where global 2/17 appears
      3. At that drive, test whether sub-regions show local 2/17 patterns

    PASS CRITERIA:
      - Global signal × 17 reaches 0.118 ± 0.02 at some drive intensity
      - At least 4 of 8 sub-regions show local partition behavior
        (sub-region gap > baseline noise)
    """
    print("=" * 78)
    print(" EXPERIMENT 2: Recursion test (local 2/17 in sub-regions)")
    print("=" * 78)
    print()

    results = {"name": "experiment_2_recursion", "tests": []}

    # ----- TEST 2.1: Find drive where global signal × 17 ≈ 0.118 -----
    print("--- TEST 2.1: Drive intensity sweep for global 2/17 signature ---")
    print(f"  Target: signal × 17 = 0.118")
    print(f"  Sweeping drive at all 8 corners...")
    print()

    corners = lattice_corner_cells(N_LATTICE)
    pattern = [1, 0, 1, 0, 1, 0, 1, 0]
    baseline_K = 0.0356

    drive_results = []
    for on_val in [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 7.5, 10.0]:
        probe = build_lattice(
            {cp: pattern for cp in corners},
            on_value=on_val,
            sample_rate=200,  # only need final state
        )
        probe.step(600)
        avg = float(np.mean([np.linalg.norm(c.K) for c in probe.lattice.cells.values()]))
        signal = avg - baseline_K
        signal_x_17 = signal * 17
        drive_results.append((on_val, avg, signal, signal_x_17))
        print(f"  drive={on_val:>5.2f}: avg_K={avg:.4f}, signal={signal:+.4f}, "
              f"signal×17={signal_x_17:+.4f}")

    # Find drive closest to target
    best = min(drive_results, key=lambda r: abs(r[3] - 0.118))
    test_passed = abs(best[3] - 0.118) < 0.05
    print()
    print(f"  Closest match: drive={best[0]} with signal×17 = {best[3]:.4f}")
    print(f"  TEST 2.1: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("2.1 global_2_17", test_passed))
    print()

    # ----- TEST 2.2: Sub-region partition -----
    print("--- TEST 2.2: Local partitions in 2×2×2 sub-regions ---")
    # Use the best drive from 2.1
    best_drive = best[0]

    probe = build_lattice(
        {cp: pattern for cp in corners},
        on_value=best_drive,
    )
    probe.step(600)

    # 8 sub-regions of size 4×4×4 (treating 8×8×8 as 2×2×2 of 4-cubes)
    sub_corners = [
        (0, 0, 0), (4, 0, 0), (0, 4, 0), (4, 4, 0),
        (0, 0, 4), (4, 0, 4), (0, 4, 4), (4, 4, 4),
    ]

    print(f"  Drive: {best_drive} at all 8 outer corners")
    print(f"  Sub-region size: 4×4×4")
    print()
    print(f"  {'sub_corner':<14s} {'TetA mean':<12s} {'TetB mean':<12s} "
          f"{'gap':<8s} {'gap > 0.01?':<10s}")

    n_with_signal = 0
    for sc in sub_corners:
        sub_part = probe.sub_region_lattice_partition(sc, size=4)
        gap = sub_part['gap']
        has_signal = abs(gap) > 0.005
        if has_signal:
            n_with_signal += 1
        print(f"  {str(sc):<14s} {sub_part['teta_mean']:<12.4f} "
              f"{sub_part['tetb_mean']:<12.4f} {gap:<+8.4f} "
              f"{'YES' if has_signal else 'no':<10s}")

    test_passed = n_with_signal >= 4
    print()
    print(f"  Sub-regions with signal: {n_with_signal}/8 (target ≥ 4)")
    print(f"  TEST 2.2: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("2.2 sub_region_partition", test_passed))
    print()

    n_pass = sum(1 for _, p in results["tests"] if p)
    n_total = len(results["tests"])
    print(f"=== EXPERIMENT 2 SUMMARY: {n_pass}/{n_total} tests passed ===")
    print()
    return results


# ============================================================================
# EXPERIMENT 3: Eigenstructure — does Cl(3) {1,3,3,1} appear at 8×8×8?
# ============================================================================

def experiment_3_eigenstructure():
    """
    HYPOTHESIS: At 4×4×4 we found partial Cl(2)-like {1,2,1} eigenstructure
    at the lattice scale. The fuller 8×8×8 lattice should reveal closer to
    full Cl(3) {1,3,3,1} = 8 modes pattern when driven appropriately.

    PROCEDURE:
      1. Drive lattice with each Walsh basis function (W_0..W_7 across 8 corners)
      2. Compute SVD of the corner-cell K-stack (8 cells × 16 components)
      3. Check for {1,3,3,1} = {1 dominant, 3 mid, 3 lower, 1 small} pattern

    PASS CRITERIA:
      - At least one drive pattern produces an SV decomposition consistent
        with {1, 3, 3, 1} (allowing for noise: groups within 5% of each other)
    """
    print("=" * 78)
    print(" EXPERIMENT 3: Cl(3) eigenstructure at 8×8×8 scale")
    print("=" * 78)
    print()

    results = {"name": "experiment_3_eigenstructure", "tests": []}

    def walsh(n, v):
        return 1 if bin(n & v).count("1") % 2 == 0 else 0

    corners = lattice_corner_cells(N_LATTICE)
    pattern = [1, 0, 1, 0, 1, 0, 1, 0]

    print(f"  Driving 8×8×8 with each Walsh basis function W_0..W_7")
    print(f"  Recording SV pattern of corner-cell K-stack (8 cells × 16)")
    print()

    sv_results = []
    target_pattern_found = False

    for n in range(8):
        drives = {}
        for v, cp in enumerate(corners):
            if walsh(n, v) == 1:
                drives[cp] = pattern
        probe = build_lattice(drives, on_value=10.0)
        probe.step(800)

        # Corner cells K-stack
        corner_K_stack = probe.region_K_stack(corners)
        U, s, Vt = np.linalg.svd(corner_K_stack, full_matrices=False)

        # Group SVs into degeneracy classes
        rounded = np.round(s, 3)
        from collections import Counter
        groups = sorted(Counter(rounded.tolist()).items(), key=lambda x: -x[0])
        groups_clean = [(v, n_vals) for v, n_vals in groups if v > 1e-6]

        n_active = sum(g[1] for g in groups_clean)
        active_str = "{" + ",".join(str(g[1]) for g in groups_clean) + "}"

        print(f"  W_{n} ({sum(walsh(n, v) for v in range(8))}/8 active corners):")
        print(f"    SVs: {[round(x, 4) for x in s.tolist()]}")
        print(f"    Active: {n_active}, pattern: {active_str}")

        # Check for {1,3,3,1} or close approximations
        sv_results.append({
            "W": n,
            "svs": s.tolist(),
            "groups": groups_clean,
            "n_active": n_active,
            "pattern": active_str,
        })

        # {1,3,3,1} = 8 active modes with grouping {1, 3, 3, 1}
        if n_active == 8 and active_str == "{1,3,3,1}":
            target_pattern_found = True
        # Also accept {1,2,2,1} (close approximation, common in finite samples)
        if active_str == "{1,3,3,1}":
            target_pattern_found = True

    test_passed = target_pattern_found
    print()
    if test_passed:
        print(f"  RESULT: {1, 3, 3, 1} pattern found.")
    else:
        print(f"  RESULT: No drive produced clean {{1,3,3,1}} pattern.")
        print(f"  Closest patterns observed:")
        for r in sv_results[:3]:
            print(f"    W_{r['W']}: {r['pattern']} (active: {r['n_active']})")
    print(f"  TEST 3.1: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("3.1 cl3_pattern", test_passed))
    print()

    # Sub-test: full lattice eigenstructure (all 512 cells)
    print("--- TEST 3.2: Full-lattice eigenstructure (all 512 cells) ---")
    # Use highest-symmetry drive (W_0)
    drives_w0 = {cp: pattern for cp in corners}
    probe = build_lattice(drives_w0, on_value=10.0)
    probe.step(800)

    es = probe.eigenstructure()
    print(f"  Total cells: 512")
    print(f"  Top 12 SVs: {[round(x, 4) for x in es['singular_values'][:12]]}")
    print(f"  Rank: {es['rank']}")
    print(f"  Degeneracy groups: {es['degeneracy_groups'][:8]}")
    print()

    # Pass if rank > 5 and at least one degenerate group
    has_degeneracy = any(n > 1 for v, n in es['degeneracy_groups'][:5])
    test_passed = es['rank'] >= 5 and has_degeneracy
    print(f"  TEST 3.2: {'PASS' if test_passed else 'FAIL'}")
    results["tests"].append(("3.2 rank_and_degeneracy", test_passed))
    print()

    n_pass = sum(1 for _, p in results["tests"] if p)
    n_total = len(results["tests"])
    print(f"=== EXPERIMENT 3 SUMMARY: {n_pass}/{n_total} tests passed ===")
    print()
    return results


# ============================================================================
# Main
# ============================================================================

def main():
    selected = None
    if len(sys.argv) > 1 and sys.argv[1] == "-e":
        selected = int(sys.argv[2]) if len(sys.argv) > 2 else None

    print()
    print("#" * 78)
    print("# 8×8×8 LATTICE EXPERIMENTS")
    print("#" * 78)
    print(f"# Lattice: 8×8×8 = 512 cells")
    print(f"# Started at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"#" * 78)
    print()

    all_results = []

    if selected is None or selected == 1:
        t0 = time.time()
        all_results.append(experiment_1_replication())
        print(f"  Experiment 1 runtime: {time.time() - t0:.1f}s")
        print()

    if selected is None or selected == 2:
        t0 = time.time()
        all_results.append(experiment_2_recursion())
        print(f"  Experiment 2 runtime: {time.time() - t0:.1f}s")
        print()

    if selected is None or selected == 3:
        t0 = time.time()
        all_results.append(experiment_3_eigenstructure())
        print(f"  Experiment 3 runtime: {time.time() - t0:.1f}s")
        print()

    # Final summary
    print("=" * 78)
    print(" FINAL SUMMARY")
    print("=" * 78)
    print()
    for r in all_results:
        passed = sum(1 for _, p in r["tests"] if p)
        total = len(r["tests"])
        print(f"  {r['name']}: {passed}/{total}")
        for tname, p in r["tests"]:
            print(f"    {'✓' if p else '✗'} {tname}")
    print()


if __name__ == "__main__":
    main()
